Place .png files in this folder to use them as tilesets for your game

Docs: https://www.gbstudio.dev/docs/assets/tilesets
